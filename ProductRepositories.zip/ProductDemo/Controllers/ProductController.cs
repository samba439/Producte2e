﻿using DomianObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProductServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductDemo.Controllers
{
    
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly IProductService _productService;

        public ProductController(ILogger<ProductController> logger, IProductService productService)
        {
            _logger = logger;
            _productService = productService;
        }
        [HttpGet]
        [Route("GetProducts")]
        public async Task<IActionResult> GetProducts()
        {
            _logger.LogInformation("Came into Get Products method");
            try
            {
                var products = await this._productService.SelectAll<Product>();
                return Ok(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                throw;
            }
        }
        [HttpPost]
        [Route("AddProduct")]
        public async Task<IActionResult> AddProduct(Product product)
        {
            _logger.LogInformation("Came into Add Products method");
            try
            {
                await this._productService.CreateAsync<Product>(product);
                _logger.LogInformation("Added Produt successfully");
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest("Something went wrong");
            }

        }

        [HttpPost]
        [Route("UpdateProduct")]
        public async Task<IActionResult> UpdateProduct(Product product)
        {
            _logger.LogInformation("Came into Add Products method");
            try
            {
                await this._productService.UpdateAsync<Product>(product);
                _logger.LogInformation("Updated Produt successfully");
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest("Something went wrong");
            }

        }
        [HttpPost]
        [Route("DeleteProduct")]
        public async Task<IActionResult> DeleteProduct(Product product)
        {
            _logger.LogInformation("Came into Add Products method");
            try
            {
                await this._productService.DeleteAsync<Product>(product);
                _logger.LogInformation("Deleted Produt successfully");
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest("Something went wrong");
            }

        }

        [HttpPost]
        [Route("GetProductById")]
        public async Task<IActionResult> GetProductById(Product product)
        {
            _logger.LogInformation("Came into Add Products method");
            try
            {
              var result=  await this._productService.SelectById<Product>(product.Id);
                _logger.LogInformation("Deleted Produt successfully");
                return Ok(result);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest("Something went wrong");
            }

        }
        
    }
}
