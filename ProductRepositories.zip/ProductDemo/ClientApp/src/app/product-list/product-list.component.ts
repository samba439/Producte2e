import { Component, OnInit } from '@angular/core';
import {
  ColDef,
  GridApi,
  ColumnApi
} from 'ag-grid-community';
import {
  Router
} from '@angular/router';
import { Product } from '../models/product';
import { ProductService } from '../services/ProductService';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  public products: Product[];
  public columnDefs: ColDef[];
  // gridApi and columnApi  
  private api: GridApi;
  private columnApi: ColumnApi;
  constructor(private router: Router, private productService: ProductService, private toastr: ToastrService) { }

  ngOnInit() {
    this.columnDefs = this.createColumnDefs()
    this.productService.getProducts().subscribe(d => {
      debugger
      this.products = d;
    }, error => {
      console.log(error)
    })
  }
  onGridReady(params): void {
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.api.sizeColumnsToFit();
  }
  // create column definitions  
  private createColumnDefs() {
    return [
      {
        headerName: 'Id',
        field: 'id',
        filter: true,
        enableSorting: true,

        sortable: true
      },
      {
      headerName: 'Name',
      field: 'name',
      filter: true,
      enableSorting: true,
     
      sortable: true
    }, {
      headerName: 'Type',
      field: 'productType',
      filter: true,
     
      sortable: true
      },
      {
        headerName: 'Price',
        field: 'price',
        filter: true,

        sortable: true
      },
      {
      headerName: 'Active',
      field: 'isActive',
      filter: true,
      sortable: true,     
      
      },
{
        headerName: 'Actions',
  cellRenderer: (data) => {
    return `
<i class="bi bi-pencil-square" style="cursor:pointer ;padding: 7px 20px 0 0;color:green;
    font-size: 17px;"   data-action-type="edit" title="Edit Product"></i>

<i class="bi bi-archive" style="cursor:pointer ;padding: 7px 20px 0 0;color:red;
    font-size: 17px;"   data-action-type="delete" title="Delete Product"></i>
    
    `},
        cellRendererParams: {
          onClick: this.deleteProduct.bind(this),
          label: 'Delete'
        },
      }
    ]
  }
  status: any;
  currentRowItem: any;
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      this.currentRowItem = data.RowData;

      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        
        case "edit":
          return this.editProduct(data);

        case "delete":
          return this.deleteProduct(data);
      }
    }
  }
  editProduct(data) {
 
    this.router.navigate(['edit-product/'+data.id]);  
    
  }
  
  deleteProduct(data) {
    if (confirm('Are you Sure? want to delete this product?')) {
     
      this.productService.deleteProduct(data).subscribe(d => {
        this.toastr.success('success', 'Product deleted successfully');
        this.ngOnInit();
        this.api.refreshRows(null);
      })
    }

  }
  Add() {
    this.router.navigate(['add-product']);
  }
}
