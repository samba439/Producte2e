import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

//import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../services/ProductService';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  submitted: boolean = false;
  productForm: any;
  productId: any;
  isAddMode: any;
  constructor(private formBuilder: FormBuilder
//, private toastr: ToastrService
    , private produtService: ProductService, private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService
      ) { }

  ngOnInit(): void {
    
    this.productId = this.route.snapshot.params['id'];
    this.isAddMode = !this.productId;
 
    this.productForm = this.formBuilder.group({
      "Id":[0],
      "Name": ["", Validators.required],
      "Price": [null,
        Validators.compose([Validators.required, Validators.pattern('^\\d{0,5}(\\.\\d{0,2})?$')])
        ],
      "ProductType": ["", Validators.required],
      "IsActive": [true, Validators.required],
      
    });
    if (!this.isAddMode) {
      this.produtService.getProductById(this.productId).subscribe(x => {
        debugger
        this.productForm.patchValue(x);
        this.productForm.patchValue({
          Id: x.id,
          Name: x.name,
          ProductType:x.productType,
          Price: x.price,
          IsActive:x.isActive
        });
      });
      
    }
  }
  get f() { return this.productForm.controls; }
  onSubmit() {
    debugger
    this.submitted = true;
    
    if (this.productForm.invalid) {
      return;
    }


    if (this.isAddMode) {
      this.produtService.addProduct(this.productForm.value)
        .subscribe(data => {
           this.toastr.success("success", "Product addedd successfully");
          this.router.navigate(['product-list']);
        }, error => {
          this.toastr.error("error", "Something went wrong");
        });
    } else {
      this.produtService.updateProduct(this.productForm.value)
        .subscribe(data => {
          this.toastr.success("success", "Updated Successfully");
          this.router.navigate(['product-list']);
        }, error => {
          this.toastr.error("error", "Something went wrong");
        });
    }
  }
  Cancel() {
    this.router.navigate(['product-list']);
  }
}
