import {
    Inject,
  Injectable
} from '@angular/core';

import {
  HttpClient,
  HttpHeaders
} from '@angular/common/http';
import {
  Observable
} from 'rxjs';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  _baseUrl: any;
  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
    //http.get<WeatherForecast[]>(baseUrl + 'weatherforecast').subscribe(result => {
    //  this.forecasts = result;
    //}, error => console.error(error));
  }


  
  currentProduct: Product;
  
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`https://localhost:44360/api/Product/GetProducts`);
  }
  addProduct(product: Product): Observable<string> {
    
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post<any>('https://localhost:44360/api/Product/AddProduct',JSON.stringify(product), httpOptions);
  }
  updateProduct(product: Product): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post<any>(`https://localhost:44360/api/Product/UpdateProduct`, JSON.stringify(product), httpOptions);
  }
  deleteProduct(product: Product): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post<string>(`https://localhost:44360/api/Product/DeleteProduct`, product, httpOptions);
  }
  getProductById(id): any {
    var product = new Product();
    product.Id = id;
    
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post<Product>(`https://localhost:44360/api/Product/GetProductById`, JSON.stringify(product) ,httpOptions);
  }
}
