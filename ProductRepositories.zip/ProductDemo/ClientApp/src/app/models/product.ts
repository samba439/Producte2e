export class Product {
  Id: number;
  Name: string;
  ProductType: string;
  Price: any;
  IsActive: boolean
}
