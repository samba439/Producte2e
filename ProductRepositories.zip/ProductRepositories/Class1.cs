﻿using System;

namespace ProductRepositories
{
    public class Class1
    {
    }
}
