using System;
using Xunit;
using ProductDemo;
using ProductServices;
using Moq;
using DomianObjects;
using ProductDemo.Controllers;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ProductDemoUnitTest
{
    public class ProductControllerTest
    {
        #region Property
         Mock<IProductService> mock = new Mock<IProductService>();
        Mock<ILogger<ProductController>> loggerMock = new Mock<ILogger<ProductController>>();
        #endregion
        [Fact]
        public async void ProductController_GetProductById_Ok()
        {
            var productData = new Product()
            {
                Id = 1,
                Name = "Test",
                ProductType = "Books",
                Price = 23,
                IsActive = true
            };
            mock.Setup(x => x.SelectById<Product>(1)).ReturnsAsync(productData);
            ProductController product = new ProductController(loggerMock.Object, mock.Object);
            var result =await product.GetProductById(new Product() { Id = 1 });
            Assert.IsType<OkObjectResult>(result);
        }
        [Fact]
        public async void ProductController_AddNewProduct_Ok()
        {
            var productData = new Product()
            {
                Id = 1,
                Name = "Test",
                ProductType = "Books",
                Price = 23,
                IsActive = true
            };
            
            mock.Setup(x => x.CreateAsync<Product>(productData)).Returns(Task.FromResult(default(object)));
            ProductController product = new ProductController(loggerMock.Object, mock.Object);
            var result = await product.AddProduct(productData);
            Assert.IsType<OkResult>(result);



        }

        [Fact]
        public async void ProductController_GetAllProducts_Ok_Counts_Match()
        {
            var productData1 = new Product()
            {
                Id = 1,
                Name = "Test",
                ProductType = "Books",
                Price = 23,
                IsActive = true
            };
            var productData2 = new Product()
            {
                Id = 2,
                Name = "Pizza",
                ProductType = "Food",
                Price = 34,
                IsActive = true
            };
            var plist = new List<Product>();
            plist.Add(productData1);
                plist.Add(productData2);
            mock.Setup(_ => _.SelectAll<Product>()).Returns(()=> Task.FromResult(new List<Product>( plist)));
            ProductController product = new ProductController(loggerMock.Object, mock.Object);
            var result = await product.GetProducts();           
            var okResult = (OkObjectResult)result;
            var list = okResult.Value as List<Product>;
            Assert.Equal(plist.Count, list.Count);

        }

        [Fact]
        public async void ProductController_Delete_Ok()
        {
            var productData = new Product()
            {
                Id = 1,
                Name = "Test",
                ProductType = "Books",
                Price = 23,
                IsActive = true
            };
            mock.Setup(x => x.DeleteAsync<Product>(productData)).Returns(Task.CompletedTask);
            ProductController product = new ProductController(loggerMock.Object, mock.Object);
            var result = await product.DeleteProduct(new Product() { Id = 1 });
            Assert.IsType<OkResult>(result);
        }

        [Fact]
        public async void ProductController_UpdateProduct_Ok()
        {
            var productData = new Product()
            {
                Id = 1,
                Name = "Test",
                ProductType = "Books",
                Price = 23,
                IsActive = true
            };
            mock.Setup(x => x.UpdateAsync<Product>(productData)).Returns(Task.CompletedTask);
            ProductController product = new ProductController(loggerMock.Object, mock.Object);
            var result = await product.UpdateProduct(productData);
            Assert.IsType<OkResult>(result);
        }
    }
}
