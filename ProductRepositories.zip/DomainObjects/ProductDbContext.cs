﻿using Microsoft.EntityFrameworkCore;
using System;

namespace DomianObjects
{
    public class ProductDbContext : DbContext
    {
        private readonly DbContextOptions _options;
        public ProductDbContext(DbContextOptions options) : base(options)
        {
            _options = options;
        }

        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
