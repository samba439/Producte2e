﻿using System;

namespace DomainObjects
{
    public class Class1
    {
    }
}
