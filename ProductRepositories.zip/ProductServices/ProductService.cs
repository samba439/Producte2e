﻿using ProductRepositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductServices
{
    public class ProductService : IProductService
    {
        private readonly IProductRepositories _repository;
        public ProductService(IProductRepositories productRepositories)
        {
            _repository = productRepositories;

        }
        public Task CreateAsync<T>(T entity) where T : class
        {
            return _repository.CreateAsync(entity);
        }

        public Task DeleteAsync<T>(T entity) where T : class
        {
            return _repository.DeleteAsync(entity);
        }

        public Task<List<T>> SelectAll<T>() where T : class
        {
            return _repository.SelectAll<T>();
        }

        public Task<T> SelectById<T>(int id) where T : class
        {
            return _repository.SelectById<T>(id);
        }

        public Task UpdateAsync<T>(T entity) where T : class
        {
            return _repository.UpdateAsync(entity);
        }
    }
}
