﻿using System;

namespace ProductServices
{
    public class Class1
    {
    }
}
